const mongo = require('mongodb')

module.exports = {
    name: 'blacklist',
    description: 'WEW',
    category: 'DevOnly',
    ownerOnly: true,
    run: async(bot, message) => {

    }
}