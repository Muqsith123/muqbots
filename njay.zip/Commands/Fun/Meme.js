const { MessageEmbed } = require('discord.js')

module.exports = {
    name: 'memeindo',
    description: 'Menambah IQ Kelean',
    category: 'Fun',
    aliases: 'mindo',
    run: async(bot, message) => {
        
    }
}